-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `EQUIPOS`;
CREATE TABLE `EQUIPOS` (
  `CodEquipo` varchar(4) NOT NULL DEFAULT '',
  `Nombre` varchar(30) NOT NULL,
  `Localidad` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`CodEquipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `EQUIPOS` (`CodEquipo`, `Nombre`, `Localidad`) VALUES
('001',	'AD Nervión',	'Sevilla'),
('002',	'Cerro del Águila',	'Sevilla'),
('003',	'CD Híspalis',	'Sevilla'),
('004',	'CD Amate',	'Sevilla'),
('005',	'CD Heliópolis',	'Sevilla');

DROP TABLE IF EXISTS `INCIDENCIAS`;
CREATE TABLE `INCIDENCIAS` (
  `NumIncidencia` varchar(6) NOT NULL DEFAULT '',
  `CodPartido` varchar(4) DEFAULT NULL,
  `CodJugador` varchar(4) DEFAULT NULL,
  `Minuto` int(2) DEFAULT NULL,
  `Tipo` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`NumIncidencia`),
  KEY `CodPartido` (`CodPartido`),
  KEY `CodJugador` (`CodJugador`),
  CONSTRAINT `INCIDENCIAS_ibfk_1` FOREIGN KEY (`CodPartido`) REFERENCES `PARTIDOS` (`CodPartido`),
  CONSTRAINT `INCIDENCIAS_ibfk_2` FOREIGN KEY (`CodJugador`) REFERENCES `JUGADORES` (`CodJugador`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `INCIDENCIAS` (`NumIncidencia`, `CodPartido`, `CodJugador`, `Minuto`, `Tipo`) VALUES
('0001',	'0001',	'001',	67,	'Amarilla'),
('0002',	'0003',	'005',	80,	'cambio'),
('0003',	'0002',	'002',	70,	'Amarilla'),
('0004',	'0004',	'004',	51,	'Roja'),
('0005',	'0005',	'003',	89,	'Cambio');

DROP TABLE IF EXISTS `JUGADORES`;
CREATE TABLE `JUGADORES` (
  `CodJugador` varchar(4) NOT NULL DEFAULT '',
  `Nombre` varchar(50) NOT NULL,
  `Fecha_Nacimiento` date DEFAULT NULL,
  `Demarcación` varchar(10) DEFAULT NULL,
  `CodEquipo` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`CodJugador`),
  KEY `CodEquipo` (`CodEquipo`),
  CONSTRAINT `JUGADORES_ibfk_1` FOREIGN KEY (`CodEquipo`) REFERENCES `EQUIPOS` (`CodEquipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `JUGADORES` (`CodJugador`, `Nombre`, `Fecha_Nacimiento`, `Demarcación`, `CodEquipo`) VALUES
('001',	'Alberto García',	'2000-02-09',	'Portero',	'001'),
('002',	'Daniel Martín',	'1999-12-10',	'Defensa',	'002'),
('003',	'Aquivaldo Mosquera',	'2000-11-21',	'Defensa',	'002'),
('004',	'Luis León',	'2000-04-04',	'Delantero',	'005'),
('005',	'Alonso',	'2000-08-01',	'MD',	'005');

DROP TABLE IF EXISTS `PARTIDOS`;
CREATE TABLE `PARTIDOS` (
  `CodPartido` varchar(4) NOT NULL DEFAULT '',
  `CodEquipoLocal` varchar(4) DEFAULT NULL,
  `CodEquipoVisitante` varchar(4) DEFAULT NULL,
  `Fecha` date DEFAULT NULL,
  `Competicion` varchar(4) DEFAULT NULL,
  `Jornada` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CodPartido`),
  KEY `CodEquipoLocal` (`CodEquipoLocal`),
  KEY `CodEquipoVisitante` (`CodEquipoVisitante`),
  CONSTRAINT `PARTIDOS_ibfk_1` FOREIGN KEY (`CodEquipoLocal`) REFERENCES `EQUIPOS` (`CodEquipo`),
  CONSTRAINT `PARTIDOS_ibfk_2` FOREIGN KEY (`CodEquipoVisitante`) REFERENCES `EQUIPOS` (`CodEquipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `PARTIDOS` (`CodPartido`, `CodEquipoLocal`, `CodEquipoVisitante`, `Fecha`, `Competicion`, `Jornada`) VALUES
('0001',	'001',	'002',	'2016-01-10',	'Liga',	'1'),
('0002',	'003',	'004',	'2016-01-10',	'Liga',	'1'),
('0003',	'001',	'003',	'2016-01-17',	'Liga',	'2'),
('0004',	'002',	'005',	'2016-01-17',	'Liga',	'2'),
('0005',	'005',	'004',	'2016-01-24',	'Liga',	'3');

-- 2016-09-26 16:02:06

